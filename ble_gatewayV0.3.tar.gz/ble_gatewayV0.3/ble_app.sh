#!/bin/sh

echo 46 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio46/direction
echo 1 > /sys/class/gpio/gpio46/value
echo 46 > /sys/class/gpio/unexport
sleep 1
hciconfig -a
hciattach -s 115200 /dev/ttymxc2 any 115200 noflow 00:00:00:00:00:01
hciconfig -a
hciconfig hci0 up
sleep 1
python3 /opt/ranchpal_BLE_gateway/ranchpal_BLE_gateway/blk_scan.py
