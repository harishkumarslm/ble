import sys
import time
import atexit
import json
import signal
import threading
import asyncio
import schedule
import socket
import logging
import requests
from datetime import datetime
from ctypes import *
from bleak import BleakScanner
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient

import logging_utils
import constants
import file_handler
import gpio_handler
import AHT25
import subprocess

#Global Variables
network_connection = False
count=0


def shutdown():
    print("Shutting down the application")
    gpio_handler.gpio_write(gpio_num=constants.OPERATION_LED, value=constants.LED_OFF)
 

def signal_handler(signal, frame):
    logging.info("SIGINT signal is received")
    exit(constants.EXIT_SUCCESS)


"""def remove_duplicates(beacon_data, field):
    if not beacon_data:
        return []

    # Check if the field is a string and is in the items of the list
    if not isinstance(field, str) or field not in beacon_data[0]:
        return beacon_data

    unique_items = {}
    for item in beacon_data:
        item_dict = eval(item)
        item_dict.pop(field, None)
        key = str(item_dict)
        # Add the item to the dictionary if it hasn't been seen before
        if key not in unique_items:
            unique_items[key] = item

    # Extract the unique items from the dictionary
    unique_list = list(unique_items.values())
    return unique_list"""


def write_back_into_file(data_list=[], fname=None):
    if not data_list or fname is None:
        return

    logging.info("Writing the data back into file - {}".format(fname))
    logging.debug("data to be written:")
    logging.debug(data_list)

    # TODO:Can check for Duplicate data before writing into file.

    for index, value in enumerate(data_list):
        data_str = json.dumps(value) + "\n"
        file_handler.write_file(file_name=fname, data=data_str)


def detection_callback(device, advertisement_data):
    global beacon_data_str
    logging.debug("detection_callback")
    try:
        if advertisement_data.local_name == constants.DEV_NAME:
            logging.debug("advertisement_data: %s", advertisement_data)
            logging.debug("Device: %s\n\n", device)
            
            dev_name = advertisement_data.local_name
            mac_id = device.address
            service_data = advertisement_data.service_data.get(constants.SERVICE_ID)
            cow_state = service_data[0]
            battery = service_data[1]
            msg_id = (service_data[3] << 8) | service_data[2]
            firmware_version = (service_data[5] << 8) | service_data[4]

            beacon_data = dict()
            beacon_data["time"] = datetime.timestamp(datetime.now())
            beacon_data["device"] = str(dev_name)
            beacon_data["mac_id"] = str(mac_id)
            beacon_data["cow_state"] = cow_state
            beacon_data["battery"] = battery
            beacon_data["message_id"] = msg_id
            beacon_data["firmware_ver"] = firmware_version

            logging.info(beacon_data)

            beacon_data_str = json.dumps(beacon_data) + "\n"
#            print("beacon_data_str: ",beacon_data_str)
            # Check for duplicate data
#            beacon_data_list = file_handler.read_file(file_name=constants.BEACON_DATA_FILE)
#            for line in beacon_data_list:
#               data_dict = json.loads(line)
#                if data_dict.get("message_id") == beacon_data.get("message_id"):
#                    logging.info("Skipping duplicate message_id: %s", msg_id)
#                    return

#            file_handler.write_file(file_name=constants.BEACON_DATA_FILE, data=beacon_data_str)
#            print("file data:",data)
    except Exception as e:
        logging.exception("Exception occured in Bleak detection_callback: %s", e)
        #raise e


async def ble_scanner():
    logging.debug("ble_scanner")
    try:
        scanner = BleakScanner()
        scanner.register_detection_callback(detection_callback)
        await scanner.start()
        await asyncio.sleep(constants.BE33_SCAN_TIME_secs)
        await scanner.stop()
        await asyncio.sleep(constants.BE33_POLL_INTERVAL_secs)
    except Exception as e:
        logging.exception("Exception occured in ble_scanner: %s", e)
        #exit()
       #exit(constants.EXIT_FAILURE)


def internet_connection_check():
    logging.debug("internet_connection_check")
    global network_connection
    try:
        sock = socket.create_connection((constants.HOST_ADDR, constants.PORT))
        if sock is not None:
            sock.close
            logging.info("Internet connection - YES")
            # Turn ON Operation LED
            gpio_handler.gpio_write(gpio_num=constants.OPERATION_LED, value=constants.LED_ON)
            
            network_connection = True
    except Exception as e:
        # OSError is expected in case of no internet
        logging.exception("Exception occured in internet_connection_check: %s", e)
        logging.info("Internet connection - NO")
        #Turn OFF operation LED
        gpio_handler.gpio_write(gpio_num=constants.OPERATION_LED, value=constants.LED_OFF)
        network_connection = False


def publish_to_cloud():
    logging.debug("publish_to_cloud")
    global count
   
    try:
        global network_connection
        if network_connection is True:
            #Publish Beacon info
#            beacon_data = file_handler.read_file(file_name=constants.BEACON_DATA_FILE)
            beacon_data = [beacon_data_str] 
#            print("read from file",beacon_data,"\n")
            #logging.info(beacon_data)
#            file_handler.clear_content(file_name=constants.BEACON_DATA_FILE)

            if beacon_data:
                beacon_data_f = [data.rstrip("\n") for data in beacon_data]   #Remove Trailing newline character
                beacon_data_f = list(set(beacon_data_f))    #Remove duplicate elements in the list

                for index, value in enumerate(beacon_data_f):
#                   print("Value",value,"/n")
                   beacon_data_f[index] = json.loads(value) 

                beacon_data_f = [beacon_data_f[i:i + constants.CHUNK_SIZE] for i in range(0, len(beacon_data_f), constants.CHUNK_SIZE)]
                logging.info("No.of chunks for beacon data is {} and max chunk size is {}".format(len(beacon_data_f), constants.CHUNK_SIZE))

                for index, value in enumerate(beacon_data_f):
                    logging.info("Chunk {} size is {}".format(index, len(value)))
                    msg = {"FULL_DATA" : value}
                    msg = {"data" : msg}
                    #msg = {"data" : }
                    #msg_json = json.dumps(msg)
                    logging.info("beacon_data chunk-{} is".format(index))
                    logging.info(msg)

                    try:
                        logging.info("[Beacon]: Request for HTTPS POST method")
                        response = requests.post(constants.CLOUD_URL_BEACON, json=msg, headers=constants.HEADERS, timeout=constants.REQEST_URL_TIMEOUT)
                        # check if the request was successful
                        logging.info("HTTPS response status code:{}".format(response.status_code))
                        if response.status_code != 200:
                            raise ValueError(f"Error: {response.status_code}")
                        # print the response data
                        logging.info("publish_response for beacon_data - %s", response.json())
                    except requests.exceptions.ConnectionError as e:
                        logging.error("Error: Failed to connect to server")
                        #write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)
                        #raise Exception("CloudConnectionError")
                    except requests.exceptions.Timeout as e:
                        logging.error("Error: Request timed out")
                        #write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)
                        #raise Exception("CloudConnectionTimeoutError")
                    except ValueError as e:
                        logging.exception(e)
                        #write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)
                        #raise Exception("NegativeResponseCode")
                    except Exception as e:
                        logging.exception(e)
                        #write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)
            else:
                logging.info("No BE33 data available to send to cloud")
                count=count+1
                print("count:-- ",count)
                if count==5:
                    subprocess.run(["rmmod", "wilc_sdio"])
                    exit()

            """#Publish AHT25 data
#            aht25_data = file_handler.read_file(file_name=constants.AHT25_DATA_FILE)
            
            aht25t_data = [aht25_data_str]
            print("before clearing string-data",aht25_data_str,"\n")
            print("READ From file:",aht25t_data,"\n")
            #logging.info(aht25_data)
            aht25_data_str = {}
            print("after clearing string-data",aht25_data_str,"\n")
#            file_handler.clear_content(file_name=constants.AHT25_DATA_FILE)
            
            
            if aht25t_data:
                aht25_data_f = [data.rstrip("\n") for data in aht25t_data] #  haracter
                aht25_data_f = list(set(aht25_data_f))    #Remove duplicate data
                print("before clearing aht25_data_f data:",aht25_data_f,"\n")
                
                for index, value in enumerate(aht25_data_f):
                    aht25_data_f[index] = json.loads(value)
                    
          
                aht25_data_f = [aht25_data_f[i:i + constants.CHUNK_SIZE] for i in range(0, len(aht25_data_f), constants.CHUNK_SIZE)]
                logging.info("No.of chunks for aht25 data is {} and max chunk size is {}".format(len(aht25_data_f), constants.CHUNK_SIZE))
                for index, value in enumerate(aht25_data_f):
                    print("before clearing value-data:",value,"\n")
                    logging.info("Chunk {} size is {}".format(index, len(value)))
                    msg = {"FULL_DATA" : value}
                    msg = {"data" : msg}
                    #msg_json = json.dumps(msg)
                    logging.info("aht25 data chunk-{} is".format(index))
                    logging.info(msg)
                  #  msg.pop("data")
                  #  print("message:",msg,"\n")

                    try:
                        logging.info("[AHT25]: Request for HTTPS POST method")
                        response = requests.post(constants.CLOUD_URL_AHT25, json=msg, headers=constants.HEADERS, timeout=constants.REQEST_URL_TIMEOUT)
                        # check if the request was successful
                        logging.info("HTTPS response status code:{}".format(response.status_code))
                        if response.status_code != 200:
                            raise ValueError(f"Error: {response.status_code}")
                        # print the response data
                        logging.info("publish_response for aht25_data - %s", response.json())
                        
                        aht25t_data.clear()                                                                                                         
                        print("after clearing aht25t_data",aht25t_data,"\n")                                                                                       
                        msg.clear()                                                                                                                 
                        print("after clearing msg data:",msg,"\n")
                        value.clear()
                        print("after clearing value-data:",value,"\n") 
                        aht25_data_f.clear()
                        print("before clearing aht25_data_f data:",aht25_data_f,"\n")
                                                                                                                         
                       # aht25_data_str = None
                       # print("aht-str-data:",aht25_data_str,"\n")
                    except requests.exceptions.ConnectionError as e:
                        logging.error("Error: Failed to connect to server")
                        #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)
                        #raise Exception("CloudConnectionError")
                    except requests.exceptions.Timeout as e:
                        logging.error("Error: Request timed out")
                        #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)
                        #raise Exception("CloudConnectionTimeoutError")
                    except ValueError as e:
                        logging.exception(e)
                        #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)
                        #raise Exception("NegativeResponseCode")
                    except Exception as e:
                        logging.exception(e)
                        #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)
                # aht25t_data.clear()
                # print("aht25t_data",aht25t_data,"\n")
                # msg.clear()
                # print("msg data:",msg,"\n")
                # aht25_data_str = None
            else:
                logging.info("No AHT25 data available to send to cloud")"""
    except Exception as e:
        #raise e
        logging.exception(e)

"""
def publish_to_cloud():
    logging.debug("publish_to_cloud")
    
    try:                                                                                                                                      
        global network_connection                                                                                                             
        if network_connection is True:
            beacon_data =  beacon_data_str 
            beacon_data_f = [data.rstrip("\n") for data in beacon_data]   #Remove Trailing newline character                              
            beacon_data_f = list(set(beacon_data_f))

            for index, value in enumerate(beacon_data_f):
                beacon_lst=[json.loads(beacon_data_str)]
                msg = {"FULL_DATA" : beacon_lst}
                msg = {"data" : msg}
                if msg:
                    try:                                                                                                                      
                        logging.info("[Beacon]: Request for HTTPS POST method")                                                             
                        response = requests.post(constants.CLOUD_URL_BEACON, json=msg, headers=constants.HEADERS, timeout=constants.REQEST_URL
                        # check if the request was successful                                     
                        logging.info("HTTPS response status code:{}".format(response.status_code))                                            
                        if response.status_code != 200:                                                                                     
                            raise ValueError(f"Error: {response.status_code}")                                                                
                        # print the response data                                                 
                        logging.info("publish_response for beacon_data - %s", response.json())                                                
                    except requests.exceptions.ConnectionError as e:                                                                        
                        logging.error("Error: Failed to connect to server")                                                                   
                        # write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)                                           
                        #raise Exception("CloudConnectionError")                                                                       
                    except requests.exceptions.Timeout as e:                                                                                
                        logging.error("Error: Request timed out")                                                                             
                        # write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)                                             
                        #raise Exception("CloudConnectionTimeoutError")                                                                
                    except ValueError as e:                                                                                                 
                        logging.exception(e)                                                                                                  
                        # write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)                                             
                        #raise Exception("NegativeResponseCode")                                                                       
                    except Exception as e:                                                                                                  
                        logging.exception(e)                                                                                                  
                        # write_back_into_file(data_list=value, fname=constants.BEACON_DATA_FILE)      
                else:                                                                                                                             
                    logging.info("No BE33 data available to send to cloud")                                                                       
                    count=count+1                                                                                                                 
                    print("count:-- ",count)                                                                                                      
                    if count==5:                                                                                                                  
                        subprocess.run(["rmmod", "wilc_sdio"])                                                                                    
                        subprocess.run(["reboot"])                                                                                                
                        exit()

                #Publish AHT25 data
                aht25_data=aht25_data_str
                aht25_data_f = [data.rstrip("\n") for data in aht25_data]   #Remove Trailing newline character                                
                aht25_data_f = list(set(aht25_data_f))    #Remove duplicate data

                for index, value in enumerate(aht25_data_f):
                    aht25_lst=[json.loads(aht25_data_str)]
                    aht_msg = {"FULL_DATA" : aht25_lst}
                    aht_msg = {"data" : aht_msg}
                    if aht_msg:
                        try:                                                                                                                      
                            logging.info("[AHT25]: Request for HTTPS POST method")                                                                
                            response = requests.post(constants.CLOUD_URL_AHT25, json=msg, headers=constants.HEADERS, timeout=constants.REQEST_URL_
                            # check if the request was successful                                                                                 
                            logging.info("HTTPS response status code:{}".format(response.status_code))                                            
                            if response.status_code != 200:                                                                                       
                                raise ValueError(f"Error: {response.status_code}")                                                                
                            # print the response data                                                                                             
                            logging.info("publish_response for aht25_data - %s", response.json())                                                 
                        except requests.exceptions.ConnectionError as e:                                                                          
                            logging.error("Error: Failed to connect to server")                                                                   
                            #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                                
                            #raise Exception("CloudConnectionError")                                                                              
                        except requests.exceptions.Timeout as e:                                                                                  
                            logging.error("Error: Request timed out")                                                                             
                            #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                                
                            #raise Exception("CloudConnectionTimeoutError")                                                                       
                        exc   
                            #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                                
                            #raise Exception("NegativeResponseCode")                                                                              
                        except Exception as e:                                                                                                    
                            logging.exception(e)                                                                                                  
                            #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                                
 ht25_data                   else:                                                                                                                             
                        logging.info("No AHT25 data available to send to cloud")                                                                      
    except Exception as e:                                                                                                                    
        #raise e                                                                                                                              
        logging.exception(e)
"""



def read_aht25_sensor():
    global aht25_data_str
    logging.debug("read_aht25_sensor")
    try:
        aht25 = AHT25.AHT25(BusNum = constants.AHT25_I2CBusNum)
    
        aht25_temperature = aht25.get_temperature()
        aht25_temperature = str(round(aht25_temperature, 3))
#        print("before clearing temp data:",aht25_temperature,"\n")
#        print(type(aht25_temperature))
        logging.debug("Temperature = {0} °C".format(aht25_temperature))
    
        aht25_humidity = aht25.get_humidity()
        aht25_humidity = str(round(aht25_humidity, 3))
#       print("before clearing humidity data:",aht25_humidity,"\n") 
        logging.debug("Humidity = {0} %RH".format(aht25_humidity))

        aht25_data = dict()
        aht25_data["time"] = datetime.timestamp(datetime.now())
        aht25_data["gateway_name"] = constants.GATEWAY_NAME
        aht25_data["mac_id"] = constants.GATEWAY_MAC_ID
        aht25_data["temperature"] = aht25_temperature
        aht25_data["humidity"] = aht25_humidity
        logging.info(aht25_data)
#        print("***************before clearing raw-data********************",aht25_data)
        aht25_data_str = json.dumps(aht25_data) + "\n"
        aht25_data.clear()
#       print("RAW data after clear:",aht25_data,"\n")
        aht25_temperature = None
        aht25_humidity = None 
#       print("after clearing humidity data:",aht25_humidity,"\n")
#        print("after clearing temperature data:",aht25_temperature,"\n")
#        file_handler.write_file(file_name=constants.AHT25_DATA_FILE, data=(json.dumps(aht25_data) + "\n"))
        #Publish AHT25 data                                                                                                               
        
        print("\n","		AHT25 PUBLISH TO CLOUD		","\n")                                                                                                                                      
        aht25t_data = [aht25_data_str]                                                                                             
#        print("before clearing string-data",aht25_data_str,"\n")                                                                          
#        print("READ From file:",aht25t_data,"\n")                                                                                  
        #logging.info(aht25_data)                                                                                                         
        aht25_data_str = None                                                                                                 
#        print("after clearing string-data",aht25_data_str,"\n")
        if aht25t_data:                                                                                                                   
            aht25_data_f = [data.rstrip("\n") for data in aht25t_data] #  haracter                                                        
            aht25_data_f = list(set(aht25_data_f))    #Remove duplicate data                                                              
#            print("before clearing aht25_data_f data:",aht25_data_f,"\n")
            for index, value in enumerate(aht25_data_f):                                                                                  
                aht25_data_f[index] = json.loads(value)
            aht25_data_f = [aht25_data_f[i:i + constants.CHUNK_SIZE] for i in range(0, len(aht25_data_f), constants.CHUNK_SIZE)]          
            logging.info("No.of chunks for aht25 data is {} and max chunk size is {}".format(len(aht25_data_f), constants.CHUNK_SIZE))    
            for index, value in enumerate(aht25_data_f):                                                                                  
#               print("before clearing value-data:",value,"\n")                                                                           
                logging.info("Chunk {} size is {}".format(index, len(value)))                                                             
                msg = {"FULL_DATA" : value}                                                                                               
                msg = {"data" : msg}                                                                                                      
                #msg_json = json.dumps(msg)                                                                                               
                logging.info("aht25 data chunk-{} is".format(index))                                                                      
                logging.info(msg)                                                                                                         
                #  msg.pop("data")                                                                                                          
                #  print("message:",msg,"\n")
                try:                                                                                                                      
                    logging.info("[AHT25]: Request for HTTPS POST method")                                                                
                    response = requests.post(constants.CLOUD_URL_AHT25, json=msg, headers=constants.HEADERS, timeout=constants.REQEST_URL_TIMEOUT)
                    # check if the request was successful                                                                                 
                    logging.info("HTTPS response status code:{}".format(response.status_code))                                            
                    if response.status_code != 200:                                                                                       
                        raise ValueError(f"Error: {response.status_code}")                                                                
                    # print the response data                                                                                             
                    logging.info("publish_response for aht25_data - %s", response.json())                                                 
                                                                                                                                              
                    aht25t_data.clear()                                                                                                   
#                    print("after clearing aht25t_data",aht25t_data,"\n")                                                                  
                    msg.clear()                                                                                                           
#                    print("after clearing msg data:",msg,"\n")                                                                            
                    value.clear()                                                                                                         
#                    print("after clearing value-data:",value,"\n")                                                                        
                    aht25_data_f.clear()                                                                                                  
#                    print("before clearing aht25_data_f data:",aht25_data_f,"\n")                                                         
                                                                                                                                              
                    # aht25_data_str = None                                                                                                
                    # print("aht-str-data:",aht25_data_str,"\n")       
                except requests.exceptions.ConnectionError as e:                                                                          
                    logging.error("Error: Failed to connect to server")                                                                   
                    #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                               
                    #raise Exception("CloudConnectionError")                                                                              
                except requests.exceptions.Timeout as e:                                                                                  
                    logging.error("Error: Request timed out")                                                                             
                    #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                               
                    #raise Exception("CloudConnectionTimeoutError")                                                                       
                except ValueError as e:                                                                                                   
                    logging.exception(e)                                                                                                  
                    #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)                                               
                    #raise Exception("NegativeResponseCode")                                                                              
                except Exception as e:                                                                                                    
                    logging.exception(e)                                                                                                  
                    #write_back_into_file(data_list=value, fname=constants.AHT25_DATA_FILE)  i
        else:                                                                                                                             
            logging.info("No AHT25 data available to send to cloud") 
    except Exception as e:
        logging.exception("Exception occured while read_aht25_sensor: %s", e)
        #raise "AHT25_sensor_read_error"


def main():
    # register a shutdown function at app exit for graceful shutdown
    atexit.register(shutdown)

    # Logging setup
    try:
        logging_utils.configure_logging(log_file=constants.LogFile, log_level=constants.LogLevel)
    except Exception as e:
        logging.exception("Exception during log setup: %s", e)
        exit(constants.EXIT_FAILURE)

    signal.signal(signal.SIGINT, signal_handler)
    #forever = threading.Event()
    #forever.wait()
    
    try:
        schedule.every(constants.NET_CHECK_INTERVAL_secs).seconds.do(internet_connection_check)
        schedule.every(constants.PUBLISH_INTERVAL_secs).seconds.do(publish_to_cloud)
        schedule.every(constants.AHT25_POLL_INTERVAL_secs).seconds.do(read_aht25_sensor)
        

        while(constants.RUN_APP):
            logging.debug("main loop")
            loop = asyncio.get_event_loop()
            loop.run_until_complete(ble_scanner())
            schedule.run_pending()
    except Exception as e:
        logging.exception(e)
        exit(constants.EXIT_FAILURE)


if __name__ == "__main__":
    main()
