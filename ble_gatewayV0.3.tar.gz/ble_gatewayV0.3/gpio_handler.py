import os

def gpio_write(gpio_num=None, value=1):
    #export
    cmd = "echo " + str(gpio_num) + " > /sys/class/gpio/export"
    os.system(cmd)

    #set direction
    cmd = "echo " + "out " + "> /sys/class/gpio/gpio" + str(gpio_num) + "/direction"
    os.system(cmd)

    #write value
    cmd = "echo " + str(value) + " > /sys/class/gpio/gpio" + str(gpio_num) + "/value"
    os.system(cmd)

    #unexport
    cmd = "echo " + str(gpio_num) + " > /sys/class/gpio/unexport"
    os.system(cmd)


def gpio_read(gpio_num=None):
    #export
    cmd = "echo " + str(gpio_num) + " > /sys/class/gpio/export"
    os.system(cmd)

    #set direction
    cmd = "echo " + "in " + "> /sys/class/gpio/gpio" + str(gpio_num) + "/direction"
    os.system(cmd)

    #read value
    cmd = "cat /sys/class/gpio/gpio" + str(gpio_num) + "/value"
    value = os.popen(cmd).read()

    #unexport
    cmd = "echo " + str(gpio_num) + " > /sys/class/gpio/unexport"
    os.system(cmd)
    return value

