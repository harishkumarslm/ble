RUN_APP = True
EXIT_FAILURE = 1
EXIT_SUCCESS = 0

#Logging setup
LogLevel = "info"
#LogFile = "ble_app.log"
LogFile = ""

#Gateway
GATEWAY_MAC_ID = "50:2D:F4:32:3C:6F"
GATEWAY_NAME = "BLE_GAT1"

#Beacon Info
DEV_NAME = "RPSS369"
SERVICE_ID = '0000abcd-0000-1000-8000-00805f9b34fb'
BEACON_DATA_FILE = "/opt/ble_gateway/ble_gw_history_packets/becon_data_packets.log"

#For Internet connectivity check
HOST_ADDR = "www.google.com"
PORT = 80

#Polling intervals
NET_CHECK_INTERVAL_secs = 5
PUBLISH_INTERVAL_secs = 10
AHT25_POLL_INTERVAL_secs = 300
BE33_POLL_INTERVAL_secs = 10
BE33_SCAN_TIME_secs = 5

#AHT25 sensor
AHT25_I2CBusNum = 0
AHT25_DATA_FILE = "/opt/ble_gateway/ble_gw_history_packets/aht25_data.log"

#Application log file
APP_LOG_FILE = "/opt/ble_gateway/ble_gw_history_packets/ble_app.log"

#LED indications
POWER_LED = 43
OPERATION_LED = 44
LED_ON = 0
LED_OFF = 1

#Cloud connection details
CLOUD_URL_BEACON = "https://ranchpal.xyz/api/events/record-data"
CLOUD_URL_AHT25 = "https://ranchpal.xyz/api/events/record-temperature-humidity-data"
HEADERS = {'content-type': 'application/json'}
REQEST_URL_TIMEOUT = 30
CHUNK_SIZE = 50
