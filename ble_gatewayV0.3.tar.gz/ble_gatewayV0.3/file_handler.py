import constants


def clear_content(file_name=constants.BEACON_DATA_FILE, seek_pos=0):
    fd = open(file_name, "r+")
    fd.seek(seek_pos)
    fd.truncate()
    fd.close()


def read_file(file_name=constants.BEACON_DATA_FILE):
    fd = open(file_name, 'r')
    lines = fd.readlines()
    fd.close()
    return lines


def write_file(file_name=constants.BEACON_DATA_FILE, data=None):
    if data is None:
        raise Exception("file_write_None_type")
    else:
        myfile = open(file_name, "a+")
        myfile.write(data)
        myfile.flush()
        myfile.close()
