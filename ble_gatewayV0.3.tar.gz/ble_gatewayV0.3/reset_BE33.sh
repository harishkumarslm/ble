#!/bin/sh

echo 46 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio46/direction
echo 1 > /sys/class/gpio/gpio46/value
echo 46 > /sys/class/gpio/unexport
