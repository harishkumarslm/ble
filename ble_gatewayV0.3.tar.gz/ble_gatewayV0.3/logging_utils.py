import logging


def configure_logging(log_file=None, log_level="debug"):
    try:
        log_level = logging._nameToLevel.get(log_level.upper(), logging.DEBUG)
        if log_file:
            # Create a file handler
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(log_level)
            # Create a logging format
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)
            # Get the logger
            logger = logging.getLogger()
            logger.setLevel(log_level)
            logger.addHandler(file_handler)
        else:
            logging.basicConfig(level=log_level, format='%(asctime)s - %(name)s %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
    except Exception as e:
        logging.exception("Error in configuring logging: %s", str(e))
        raise e

