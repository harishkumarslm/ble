# ranchpal_BLE_gateway


# Setting up the Debian RootFS 11.5 for the application

After flashing the images and debian 11.5 root file system. Follow the below steps to setup the Debian RFS

Step-1: Update the network configuration for eth0 by coping the below content and provided proper address, netmask and gateway as per the network.

			$ vi /etc/network/interfaces
			Copy the below content to the above file
			# interfaces(5) file used by ifup(8) and ifdown(8)
			# Include files from /etc/network/interfaces.d:
			source /etc/network/interfaces.d/*
			
			# The loopback network interface
			auto lo
			iface lo inet loopback   
			
			# The primary network interface
			auto eth0
			iface eth0  inet static
			address 192.168.1.151
			netmask 255.255.255.0
			gateway 192.168.1.1
			# dns-nameservers 192.168.2.254
	
Step-2: Set the Board date and time to current day and time

		date
		date -s "12 DEC 2022 18:00:00" // Use the current date and time

Step-3: Update, upgrade the system package manager and install the below required packages

		sudo apt-get update
		sudo apt-get upgrade
		sudo apt-get install bluez
		sudo apt-get install python3-pip
		sudo apt-get install rfkill

Step-4: Install the below python packages.

		pip3 install schedule
		pip3 install bleak
		pip3 install AWSIoTPythonSDK
		pip3 install gpiod
		pip3 install requests
        pip3 install smbus2


# Debuging Bluetooth BE33 module to scan the devices

The below commands are used to bring up the bluttoth BE33 module and scan for the bluetooth near by devices.

		hciconfig -a
		hciattach -s 115200 /dev/ttymxc2 any 115200 noflow 00:00:00:00:00:01
		hciconfig -a
		sudo hciconfig hci0 up
		sudo hcitool lescan


# Running the Gateway Application

After the Debian 11.5 RFS.

Step-1: Copy the application files and library files into the /opt/ble_gateway/ directory

Step-2: Add the systemd service(ble_app.service) in the /lib/systemd/system/ directory and ble_app.sh in the /usr/bin directory. And then enable the service using the below command

        $ systemctl enable /lib/systemd/system/ble_app.service

Step-3: Power reset the board. On the next boot, application will run automatically.
